from LsPrePost import execute_command, echo
from LsPrePost import check_if_part_is_active_u as check_u
from LsPrePost import cmd_result_get_value_count as crgvc
from LsPrePost import cmd_result_get_value as crgv
import DataCenter as dc

# open the txt file for output
f = open('exam4a.txt', 'w+')
# To keep only Solid part, turn off other type of elements
execute_command('selectpart beam off')
execute_command('selectpart shell off')
execute_command('selectpart tshell off')

part_num = dc.get_data('num_validparts')
buf='No .of valid parts='+str(part_num)
echo(buf)
# extract the part ids
validpart_ids = dc.get_data('validpart_ids')
# Write header to the excel file
# There are 13 values from the measure angvel command
f.write('Pid, Mass, Ke, CGx, CGy, CGz, vx,vy,vz,vr, wx,wy,wz,wr \n')
part_num=validpart_ids.__len__()
for i in range(part_num):
    id = validpart_ids[i]
    # Check if the part is active or not
    ret = check_u(id)
    buf = 'part id='+str(id)+', active='+str(ret)
    echo(buf)
    # Process only active parts
    if ret == 1:
        # built command to measure part inertia
        cmdbuf = 'measure angvel part H'+str(id)
        execute_command(cmdbuf)
        # Get no. of data from the measure command
        noret = crgvc()
        buf = 'No. of result values='+str(noret)
        echo(buf)
        if noret !=0:
            buf = str(id)
        # output 13 values, 
        #Mass, ke, CGx, CGy, CGz 
        #vx,vy,vz,vresultant
        #wx,wy,wz,wresultant
            for j in range(0, 13):
                fv = crgv(j)
                tmbuf = ', '+str(fv)
                buf = buf + tmbuf
            echo(buf)
        # write the buffer to the excel file 
        f.write(buf+'\n')

f.close()